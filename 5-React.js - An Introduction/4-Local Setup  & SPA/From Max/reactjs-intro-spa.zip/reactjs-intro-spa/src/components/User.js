import React from 'react';
import Info from './Info';

export default function (props) {
    return (
        <div>
            <h1>The User Page</h1>
            <Info/>
        </div>
    );
}