import React from 'react';

export default function (props) {
    return (
        <div>
            <h1>The Account Page</h1>
        </div>
    );
}