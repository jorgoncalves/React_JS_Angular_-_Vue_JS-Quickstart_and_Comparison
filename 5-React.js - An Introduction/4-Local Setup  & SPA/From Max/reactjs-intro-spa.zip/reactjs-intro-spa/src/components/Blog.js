import React from 'react';

export default function (props) {
    return (
        <div>
            <h1>The Blog Page</h1>
        </div>
    );
}