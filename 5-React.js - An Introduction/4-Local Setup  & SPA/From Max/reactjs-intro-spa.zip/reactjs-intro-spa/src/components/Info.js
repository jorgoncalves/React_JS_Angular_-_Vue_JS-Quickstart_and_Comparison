import React, { Component } from 'react';

class Info extends Component {
    render() {
        return (
            <div>
                <h1>The Info</h1>
                <p>React is awesome!</p>
            </div>
        );
    }
}

export default Info;